ProjODT
=======

But : Rechercher des fichiers .odt instantanément

Pour démarrer le programme, il y a 2 manières de faire :
* L'une dite graphique
* L'autre dans le terminal précédemment ouvert

Dans les deux cas, votre programme va s'éxecuter à l'aide de la commande (si vous êtes bien dans le dossier du fichier éxecutable) :
"java -jar projODT.jar"

Partie graphique
----------------

Vous pourrez trouver une version illustrée de ce manuel à l'adresse: http://akkes.fr/projets/projodt/manuel/
Pour la partie graphique, c'est l'unique commande à rentrer pour lancer le programme.

La barre de menu possède plusieurs onglets :

* Fichier :
	* Changer la racine (ctrl+R) : change le répertoire racine des fichiers .odt dans lesquels effectuer la recherche
	* Syncroniser (ctrl+S) : reparcourt tout depuis la racine pour actualiser les fichiers .odt
	* Fermer (ctrl+W) : quitte le programme
* Aide :
 	* Manuel d'utilisation : procure une aide plus avancée
	* A propos : fournit les informations sur le logiciel

L'écran de la fenêtre est composé de 2 parties. Celle du haut correspond à la barre de recherche, celle du bas est l'écran des résultats.

La recherche peut s'effectuer à l'aide d'opérateurs : ET et OU. Le ET est prioritaire et sera traité en premier lors de la recherche. Celle-ci est automatique et lorsque la recherche est effectuée, les résultats sont affichés en-dessous.
Pour ouvrir le fichier résultant de la recherche, il suffit de double-cliquer dessus.
Un clic simple sur la citation trouvée ouvre l'image associée au fichier .odt et affiche les informations importantes correspondante au fichier.

Partie console
--------------

Pour la partie console, il faut rajouter à cette commande certaines actions/options :

* display fichierOdtATraiter : permet d'afficher tous les titres et les informations utiles du fichier passé en paramètre
* list  : permet de lister tous les fichiers .odt à partir du répertoire racine actuel dans la base de données
	* [-d repertoireATraiter], [--database repertoireATraiter] liste tous les fichiers .odt à partir du répertoire passé en paramètre
* sync : permet de mettre à jour la base de données.
	* [-d repertoireATraiter], [--database repertoireATraiter] met à jour la base passée en paramètre
* search termesARechercher : permet de rechercher un terme dans la base de données actuelle. Il existe la possibilité d'effectuer la recherche à l'aide des opérateurs ET et OU. Pour cela, il suffit de séparer les termes à rechercher par " ET " et/ou " OU " (le ET est prioritaire et sera traité en premier)
	* [-d repertoireATraiter], [--database repertoireATraiter]  recherche à partir du répertoire passé en paramètre
* open termesARechercher : ouvre le fichier odt contenant les termes recherchés
	* [-d repertoireATraiter], [--database repertoireATraiter]  recherche à partir du répertoire passé en paramètre
* [-h], [--help] : affiche l'aide du logiciel

